#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    int seguir = 1;
    int opcion;
    int dni;
    int turnoUrg = 0;
    int turnoReg = 0;

    ArrayList* UrgAtendidos = al_newArrayList();
    ArrayList* UrgNoAtendidos = al_newArrayList();
    ArrayList* RegAtendidos = al_newArrayList();
    ArrayList* RegNoAtendidos = al_newArrayList();

    while (seguir == 1) {

        printf("\n\t\t~ Bienvenido ~\n\n");

        printf("1- Tramite urgente\n");
        printf("2- Tramite regular\n");
        printf("3- Proximo cliente\n");
        printf("4- Listar\n");
        printf("5- Informar\n");
        printf("6- Salir\n");

        printf("\nIngrese la opcion deseada: ");
        opcion = getIntRange(1, 6);

        switch (opcion)
        {
            case 1:

                turnoUrg++;
                printf("\nIngrese su DNI (5000000 - 50000000): ");
                dni = getIntRange(5000000, 50000000);
                sTramite* aux = nuevoTramite(dni, turnoUrg);
                UrgNoAtendidos->add(UrgNoAtendidos, aux);

                printf("\nSu numero de turno es: %i\n", turnoUrg);

                break;

            case 2:

                turnoReg++;
                printf("\nIngrese su DNI (5000000 - 50000000): ");
                dni = getIntRange(5000000, 50000000);
                sTramite* aux2 = nuevoTramite(dni, turnoReg);
                RegNoAtendidos->add(RegNoAtendidos, aux2);

                printf("\nSu numero de turno es: %i\n", turnoReg);

                break;

            case 3:

                if (UrgNoAtendidos->isEmpty(UrgNoAtendidos) != 1) {

                    sTramite* auxTram = UrgNoAtendidos->pop(UrgNoAtendidos, 0);

                    if (auxTram != NULL) {

                        UrgAtendidos->add(UrgAtendidos, auxTram);

                        printf("\nEl tramite urgente numero %i puede pasar\n", auxTram->turno);

                    }

                } else if (RegNoAtendidos->isEmpty(RegNoAtendidos) != 1) {

                    sTramite* auxTram2 = RegNoAtendidos->pop(RegNoAtendidos, 0);

                    if (auxTram2 != NULL) {

                        RegAtendidos->add(RegAtendidos, auxTram2);

                        printf("\nEl tramite regular numero %i puede pasar\n", auxTram2->turno);

                    }

                } else {

                    printf("\nNo hay tramites en espera.\n");

                }

                break;

            case 4:

                if (UrgNoAtendidos->isEmpty(UrgNoAtendidos) != 1) {

                    printf("\nTramites urgentes en espera:\n\n");
                    printTramiteArray(UrgNoAtendidos);

                } else {

                    printf("\nNo hay tramites urgentes en espera.\n");

                }

                if (RegNoAtendidos->isEmpty(RegNoAtendidos) != 1) {

                    printf("\nTramites regulares en espera:\n\n");
                    printTramiteArray(RegNoAtendidos);

                } else {

                    printf("\nNo hay tramites regulares en espera.\n");

                }


                break;

            case 5:

                if (UrgAtendidos->isEmpty(UrgAtendidos) != 1) {

                    printf("\nTramites urgentes atendidos:\n\n");

                    ArrayList* auxUrg = al_clone(UrgAtendidos);
                    auxUrg->sort(auxUrg, compararTramitePorDNI, 1);
                    printTramiteArray(auxUrg);

                } else {

                    printf("\nNo hay tramites urgentes atendidos.\n");

                }

                if (RegAtendidos->isEmpty(RegAtendidos) != 1) {

                    printf("\nTramites regulares atendidos:\n\n");

                    ArrayList* auxReg = al_clone(RegAtendidos);
                    auxReg->sort(auxReg, compararTramitePorDNI, 1);
                    printTramiteArray(auxReg);

                } else {

                    printf("\nNo hay tramites regulares atendidos.\n");

                }

                break;

            case 6:

                seguir = 0;
                break;

        }

    printf("\n");
    system("pause");
    system("cls");

    }

    return 0;
}
