#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "ArrayList.h"

void mostrarMenu() {

    printf("\n\n\t\t\t\t~ Bienvenido ~\n\n");

    printf("1- Agregar pelicula\n");
    printf("2- Borrar pelicula\n");
    printf("3- Modificar pelicula\n");
    printf("4- Generar pagina web\n");
    printf("5- Salir\n");

    printf("\nIngrese la opcion deseada: ");

}

// Print Empleado

void printTramite(sTramite* tramite) {

    printf("TURNO: %i\tDNI: %i\n", tramite->turno, tramite->dni);

}

// Print ArrayList Empleados

void printTramiteArray(ArrayList* arrList) {

    int i;
    int tam;

    if (arrList != NULL) {

        tam = arrList->len(arrList);

        for (i = 0; i < tam; i++) {

            sTramite* aux = arrList->get(arrList,i);
            printTramite(aux);

        }

    }

}

// Comparar por atributo

int compararTramitePorDNI(void* pTramiteA, void* pTramiteB) {

    if(((sTramite*)pTramiteA)->dni > ((sTramite*)pTramiteB)->dni) {

        return 1;

    }

    if(((sTramite*)pTramiteA)->dni < ((sTramite*)pTramiteB)->dni) {

        return -1;

    }

    return 0;
}

// Atributo repetido

int nombreRepetido(ArrayList* arrList, char cad[]) {

    int i;
    int tam;

    if (arrList != NULL) {

        tam = arrList->len(arrList);

        for (i = 0; i < tam; i++) {

            if (strcmpi(cad, ((sEmpleado*)arrList->pElements[i])->nombre == 0)) {

                return 1;

            }

        }

    }

    return 0;
}

// Setter

int setSueldo(ArrayList* arrList, float sueldo) {

    int i;
    int tam;
    int indice;
    int retorno = -1;

    if (arrList != NULL) {

        tam = arrList->len(arrList);
        printf("Lista: \n");

        for (i = 0; i < tam; i++) {

            printf("\n%i- %s", i, ((sEmpleado*)arrList->pElements[i])->nombre);

        }

        //printf("\nIngrese la persona deseada segun su indice %i-%i: ", 0, tam-1);
        indice = getIntRange(0, tam-1);

        ((sEmpleado*)arrList->pElements[indice])->sueldo = sueldo;

        retorno = 0;

    }

    return retorno;

}

// Getter

float getSueldo(ArrayList* arrList) {

    int i;
    int tam;
    int indice;
    void* aux;
    float retorno = -1;

    if (arrList != NULL) {

        tam = arrList->len(arrList);
        printf("Lista: \n");

        for (i = 0; i < tam; i++) {

            printf("\n%i- %s", i, ((sEmpleado*)arrList->pElements[i])->nombre);

        }

        //printf("\nIngrese la persona deseada segun su indice %i-%i: ", 0, tam-1);
        indice = getIntRange(0, tam-1);

        aux = arrList->get(arrList, indice);

        if (aux != NULL) {

            retorno = ((sEmpleado*)aux)->sueldo;

        }

    }

    return retorno;
}

// Constructor vacio

sEmpleado* nuevoEmpleado() {

    sEmpleado* returnAux = NULL;
    sEmpleado* pEmpleado = malloc(sizeof(sEmpleado));

    if (pEmpleado != NULL) {

        returnAux = pEmpleado;

    }

    return returnAux;
}

// Constructor parametrizado

sEmpleado* nuevoEmpleadoParam(char nombre[], char apellido[], float sueldo, int sector) {

    sEmpleado* returnAux = NULL;
    sEmpleado* pEmpleado = malloc(sizeof(sEmpleado));

    if(pEmpleado != NULL) {

        strcpy(pEmpleado->nombre, nombre);
        strcpy(pEmpleado->apellido, apellido);
        pEmpleado->sueldo = sueldo;
        pEmpleado->sector = sector;
        pEmpleado->vacio = 0;
        returnAux = pEmpleado;

    }

    return returnAux;
}

sTramite* nuevoTramite(int dni, int turno) {

    sTramite* returnAux = NULL;
    sTramite* pTramite = malloc(sizeof(sTramite));

    if(pTramite != NULL) {

        pTramite->dni = dni;
        pTramite->turno = turno;
        returnAux = pTramite;

    }

    return returnAux;
}

char* getString() {

    char cadena[250];

    printf("\nIngrese una string (solo letras y espacios): ");
    fflush(stdin);
    gets(cadena);

    int soloEsp = soloEspacios(cadena);
    int soloLet = soloLetras(cadena);

    while (soloEsp || !soloLet) {

        printf("Entrada invalida. Reingrese: ");
        fflush(stdin);
        gets(cadena);

        soloEsp = soloEspacios(cadena);
        soloLet = soloLetras(cadena);

    }

    return cadena;
}

char* getStringNum() {

    char cadena[250];

    printf("\nIngrese una string (solo letras, espacios o numeros): ");
    fflush(stdin);
    gets(cadena);

    int soloEsp = soloEspacios(cadena);
    int soloLetNum = soloLetrasONum(cadena);

    while (soloEsp || !soloLetNum) {

        printf("Entrada invalida. Reingrese: ");
        fflush(stdin);
        gets(cadena);

        soloEsp = soloEspacios(cadena);
        soloLetNum = soloLetrasONum(cadena);

    }

    return cadena;
}

int getIntRange(int min, int max) {

    char cadena[250];

    fflush(stdin);
    gets(cadena);

    int soloNum = soloNumeros(cadena);
    int valid = validarRangoInt(atoi(cadena), min, max);

    while (!soloNum || !valid) {

        printf("Entrada invalida. Reingrese (%i - %i): ", min, max);
        fflush(stdin);
        gets(cadena);

        soloNum = soloNumeros(cadena);
        valid = validarRangoInt(atoi(cadena), min, max);

    }

    return atoi(cadena);
}

int getInt() {

    char cadena[250];

    printf("\nIngrese un numero: ");
    fflush(stdin);
    gets(cadena);

    int soloNum = soloNumeros(cadena);

    while (!soloNum) {

        printf("Entrada invalida. Reingrese: ");
        fflush(stdin);
        gets(cadena);

        soloNum = soloNumeros(cadena);

    }

    return atoi(cadena);
}

int validarRangoInt(int num, int min, int max) {

    if (num >= min && num <= max) {

        return 1;

    } else {

        return 0;

    }

}

int soloNumeros(char num[]) {

    int i;
    int testNum;
    int cantString = strlen(num);

    for (i = 0; i < cantString; i++) {

        testNum = esNum(num[i]);

        if (testNum == 1) {

            if (i == (cantString - 1)) {

                return 1;

            }

        } else {

            return 0;

        }

    }

}

int soloEspacios(char nombre[]) {

    int i;
    int soloEsp = 1;
    int cantString = strlen(nombre);

    for (i = 0; i < cantString; i++) {

        if (nombre[i] != 32) {

            soloEsp = 0;
            return soloEsp;

        }

    }

    return soloEsp;

}

int soloLetras(char nombre[]) {

    int i;
    int testLetra;
    int cantString = strlen(nombre);

    for (i = 0; i < cantString; i++) {

        testLetra = esLetra(nombre[i]);

        if (testLetra == 1) {

            if (i == (cantString - 1)) {

                return 1;

            }

        } else {

            return 0;

        }

    }

}

int soloLetrasONum(char nombre[]) {

    int i;
    int testLetra;
    int cantString = strlen(nombre);

    for (i = 0; i < cantString; i++) {

        testLetra = esLetraoNum(nombre[i]);

        if (testLetra == 1) {

            if (i == (cantString - 1)) {

                return 1;

            }

        } else {

            return 0;

        }

    }

}

int esLetraoNum(char a) {

    if ((a >= 65 && a <= 90) || (a >= 97 && a <= 122) || (a >= 160 && a <= 165) || (a == 32) || (a >= 48 && a <= 57)) {

        return 1;

    } else {

        return 0;

    }

}

int esLetra(char a) {

    if ((a >= 65 && a <= 90) || (a >= 97 && a <= 122) || (a >= 160 && a <= 165) || (a == 32)) {

        return 1;

    } else {

        return 0;

    }

}

int esNum(char a) {

    if (a >= 48 && a <= 57) {

        return 1;

    } else {

        return 0;

    }

}

