#include <stdio.h>
#include <stdlib.h>

typedef struct {

    int sueldo;
    char nombre[50];

} sPersona;

int main()
{
    int orden;
    void* arrlist;

    sPersona personas[2];
    personas[0].sueldo = 1;
    personas[1].sueldo = 2;

    arrlist = al_newArrayList();
    al_add(arrlist, personas[0]);
    al_add(arrlist, personas[1]);

    al_sort(arrlist, compararPersonaSueldo(arrlist->pElements[0], arrlist->pElements[1]), 1);

    for (i = 0; i < 2; i++) {

        printf("%i\n", arrlist->pElements[i].sueldo);

    }

    return 0;
}

int compararPersonaSueldo(sPersona persona1, sPersona persona2) {

    if (persona1->sueldo > persona2->sueldo) {

        return 1;

    } else if (persona1->sueldo < persona2->sueldo) {

        return -1;

    }

    return 0;
}

int compararPersonaNombre(sPersona persona1, sPersona persona2) {

    if (strcmp(persona1->nombre, persona2->nombre) > 0) {

        return 1;

    } else if (strcmp(persona1->nombre, persona2->nombre) < 0) {

        return -1;

    }

    return 0;
}
