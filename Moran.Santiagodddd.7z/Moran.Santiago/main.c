#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    int seguir = 1;
    int opcion;
    ArrayList* notas = al_newArrayList();

    while (seguir == 1) {

        printf("\n\t\t~ Bienvenido ~\n\n");

        printf("1- Leer archivo\n");
        printf("2- Reproducir\n");
        printf("3- Ecualizar\n");
        printf("4- Correccion\n");
        printf("5- Informar\n");
        printf("6- Salir\n");

        printf("\nIngrese la opcion deseada: ");
        opcion = getIntRange(1, 6);

        switch (opcion)
        {
            case 1:
                leerArchivos(notas);
                break;

            case 2:

                break;

            case 3:

                break;

            case 4:

                break;

            case 5:

                break;

            case 6:

                seguir = 0;
                break;

        }

    printf("\n");
    system("pause");
    system("cls");

    }

    return 0;
}
