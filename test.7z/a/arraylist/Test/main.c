#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

typedef struct {

    int sueldo;
    char nombre[50];

} sPersona;

int compararPersonaSueldo(void* persona1, void* persona2);

int main()
{
    int orden;
    ArrayList* arrlist = al_newArrayList();
    printf("%d\n", arrlist->len(arrlist));

    int i;

    sPersona* persona, *aux;

    persona = malloc(sizeof(sPersona));

    sPersona* persona1;

    persona1 = malloc(sizeof(sPersona));

    persona1->sueldo=1000;
    persona->sueldo=2000;


    arrlist->add(arrlist,persona);
    arrlist->add(arrlist,persona1);

   printf("agregue %d\n", arrlist->len(arrlist));

    al_sort(arrlist, compararPersonaSueldo, 1);

    for (i = 0; i <arrlist->len(arrlist); i++) {

        aux = (sPersona*) arrlist->get(arrlist,i);
        printf("\n%i\n", aux->sueldo);

    }

    return 0;
}

int compararPersonaSueldo(void* persona1, void* persona2) {

    if(((sPersona*)persona1)->sueldo > ((sPersona*)persona2)->sueldo) {

        return 1;

    }

    if(((sPersona*)persona1)->sueldo < ((sPersona*)persona2)->sueldo) {

        return -1;

    }

    return 0;
}
