#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    int seguir = 1;
    int opcion;
    int vacio;
    int flag1 = 0, flag2 = 0;
    ArrayList* notas = al_newArrayList();

    while (seguir == 1) {

        printf("\n\t\t~ Bienvenido ~\n\n");

        printf("1- Leer archivo\n");
        printf("2- Reproducir\n");
        printf("3- Ecualizar\n");
        printf("4- Correccion\n");
        printf("5- Salir\n");

        printf("\nIngrese la opcion deseada: ");
        opcion = getIntRange(1, 5);

        switch (opcion)
        {
            case 1:
                if (!flag1) {

                    leerArchivos(notas);
                    flag1 = 1;

                } else {

                    printf("\nLos archivos ya fueron leidos\n");

                }

                break;

            case 2:
                vacio = notas->isEmpty(notas);
                if (vacio != 1) {

                    reproducir(notas);

                } else {

                    printf("\nAun no fueron leidos los archivos\n");

                }

                break;

            case 3:
                vacio = notas->isEmpty(notas);
                if (vacio != 1) {

                    ecualizar(notas);

                } else {

                    printf("\nAun no fueron leidos los archivos\n");

                }
                break;

            case 4:
                if (!flag2) {

                    correccion();
                    flag2 = 1;

                } else {

                    printf("\nLa correccion ya fue realizada\n");

                }

                break;

            case 5:
                seguir = 0;
                break;

        }

    printf("\n");
    system("pause");
    system("cls");

    }

    return 0;
}
