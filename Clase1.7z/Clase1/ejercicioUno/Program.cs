﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicioUno
{
    class Program
    {
        static void Main(string[] args)
        {

            int num;
            int cant = 5;
            int menor = 0;
            int mayor = 0;
            int suma = 0;
            int cantPares = 0;
            int lugarPrimerPar;
            int lugarUltimoImpar;
            int primerPar;
            int ultimoImpar;
            int i = 0;
            bool banderaPar = false;
            float promedio;
            string dato;


            for (i = 0; i < cant; i++) {

                Console.Write("Ingrese un numero: ");
                dato = Console.ReadLine();

                while (!int.TryParse(dato, out num)) {

                    Console.Write("Entrada invalida. Reingrese: ");
                    dato = Console.ReadLine();

                }

                if (i == 0)
                {

                    menor = num;
                    mayor = num;

                } else {

                    if (num < menor) {

                        menor = num;

                    } else if (num > mayor) {

                        mayor = num;

                    }

                }

                if (!banderaPar) {

                    if ((num % 2) == 0) {

                        primerPar = num;
                        lugarPrimerPar = i + 1;
                        banderaPar = true;

                    }

                }

                if ((num % 2) != 0) {

                    ultimoImpar = num;
                    lugarPrimerPar = i + 1;

                }

                if ((num % 2) == 0) {

                    cantPares++;

                }

                suma += num;

            }

            Console.WriteLine("El mayor es " + mayor);
            Console.WriteLine("El menor es " + menor);
            Console.WriteLine("La suma es " + suma);
            Console.WriteLine("La cantidad de pares es " + cantPares);
            Console.WriteLine("El primer par es " + primerPar);
            Console.WriteLine("La posicion del primer par es " + lugarPrimerPar);
            Console.WriteLine("El ultimo impar es " + ultimoImpar);
            Console.WriteLine("La posicion del ultimo impar es " + ultimoImpar);
            Console.Read();

        }
    }
}
