﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace primerApp
{
    class Program
    {
        static void Main(string[] args)
        {

            int numUno;
            int numDos;
            int numTres;
            int resultado;
            bool check;
            string dato;
            
            Console.Write("Ingrese el primer numero: ");
            dato = Console.ReadLine();

            while (!int.TryParse(dato, out numUno)) {

                Console.Write("Entrada invalida, reingrese: ");
                dato = Console.ReadLine();

            }

            Console.Write("Ingrese el segundo numero: ");
            dato = Console.ReadLine();
            check = int.TryParse(dato, out numDos);

            while (!check) {

                Console.Write("Entrada invalida, reingrese: ");
                dato = Console.ReadLine();
                check = int.TryParse(dato, out numDos);
            
            }

            Console.Write("Ingrese el ultimo numero: ");
            dato = Console.ReadLine();
            check = int.TryParse(dato, out numTres);

            while (!check)
            {

                Console.Write("Entrada invalida, reingrese: ");
                dato = Console.ReadLine();
                check = int.TryParse(dato, out numTres);

            }

            resultado = numUno + numDos + numTres;

            Console.WriteLine("El resultado es "+ resultado);
            Console.Read();

        }
    }
}